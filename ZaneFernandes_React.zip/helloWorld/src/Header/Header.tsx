export default function Header() {
  return (
    <header className="Header">
      <h1>Counter</h1>
    </header>
  );
}
