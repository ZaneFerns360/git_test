import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import userEvent from "@testing-library/user-event";
import Counter from "./Counter";

describe("Counter component", () => {
        let user: ReturnType<typeof userEvent.setup>;

        const getCount = () => {
                const heading = screen.getByRole("heading");
                const value = heading.textContent?.replace("Count: ", "");
                return Number(value);
        };

        beforeEach(() => {
                user = userEvent.setup();
                render(<Counter />);
        });

        it("renders with initial count 0", () => {
                expect(screen.getByTestId("counter")).toBeInTheDocument();
                expect(getCount()).toBe(0);
        });

        it("increments count when increment button is clicked", async () => {
                await user.click(screen.getByRole("button", { name: /increment/i }));
                expect(getCount()).toBe(1);
        });

        it("decrements count when decrement button is clicked", async () => {
                await user.click(screen.getByRole("button", { name: /increment/i }));
                expect(getCount()).toBe(1);

                await user.click(screen.getByRole("button", { name: /decrement/i }));
                expect(getCount()).toBe(0);
        });

        it("does not decrement below zero", async () => {
                await user.click(screen.getByRole("button", { name: /decrement/i }));
                expect(getCount()).toBe(0);
        });

        it("resets count to zero", async () => {
                await user.click(screen.getByRole("button", { name: /increment/i }));
                await user.click(screen.getByRole("button", { name: /increment/i }));
                expect(getCount()).toBe(2);

                await user.click(screen.getByRole("button", { name: /reset/i }));
                expect(getCount()).toBe(0);
        });
});

