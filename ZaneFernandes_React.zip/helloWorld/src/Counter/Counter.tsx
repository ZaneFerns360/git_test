import { useState } from 'react';

function Counter() {
        const [count, setCount] = useState(0);

        const handleIncrement = () => {
                setCount(count + 1);
        };

        const handleDecrement = () => {
                if (count > 0) {
                        setCount(count - 1);
                }
        };

        const handleReset = () => {
                setCount(0);
        };

        return (
                <div className="counter-container" data-testid="counter" id='counter'>
                        <h1 >Count: {count}</h1>
                        <button onClick={handleIncrement}>Increment</button>
                        <button onClick={handleDecrement}>Decrement</button>
                        <button onClick={handleReset}>Reset</button>
                </div>
        );
}

export default Counter;

