export interface Task {
        name: string;
        isDone: boolean
}
export const tasks: Task[] = [
        { name: "Read Springboot", isDone: false },
        { name: "Complete Assignments", isDone: true },
        { name: "Prepare Breakfast", isDone: false },
        { name: "Sleep for 2 hours", isDone: false }
];
