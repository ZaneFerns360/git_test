import { useState } from "react";
import { type Task } from "./data";
import { useEffect } from "react";

export default function TodoList() {
  const [taskList, setTaskList] = useState<Task[]>([]);
  const [newTask, setNewTask] = useState("");

  useEffect(() => {
    const fetchTodos = async () => {
      try {
        const response = await fetch("http://localhost:3000/api/todos");
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = (await response.json()) as Task[];
        setTaskList(data);
      } catch (err) {
        console.error("Failed to fetch:", err);
      }
    };

    fetchTodos();
  }, []);

  const deleteDoneTasks = () => {
    const updatedTasks = taskList.filter(
      (taskListing) => taskListing.isDone !== true,
    );
    setTaskList(updatedTasks);
  };

  const doTask = (indexToDo: number) => {
    const updatedTasks = [...taskList];
    updatedTasks[indexToDo].isDone = !updatedTasks[indexToDo].isDone;
    setTaskList(updatedTasks);
  };

  const addTask = () => {
    if (newTask.trim() === "") return;
    setTaskList([...taskList, { name: newTask, isDone: false }]);
    setNewTask("");
  };

  return (
    <div className="Header">
      <h2>Todo List</h2>

      {taskList.length === 0 ? (
        <h2>No tasks left! Go relax. </h2>
      ) : (
        <div>
          <ul
            style={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-around",
            }}
          >
            {taskList.map((task, index) => (
              <li
                key={index}
                className={task.isDone ? "task-done" : "task-not-done"}
              >
                <input
                  type="checkbox"
                  checked={task.isDone}
                  onClick={() => doTask(index)}
                />
                <span
                  onClick={() => doTask(index)}
                  style={{ cursor: "pointer" }}
                >
                  {task.name}
                </span>
              </li>
            ))}
          </ul>
          <div style={{ marginBottom: "10px" }}>
            <input
              type="text"
              value={newTask}
              onChange={(e) => setNewTask(e.target.value)}
              style={{ padding: "4px", marginRight: "6px" }}
            />
            <button onClick={addTask}>Add</button>
          </div>

          <button onClick={() => deleteDoneTasks()} style={{ color: "red" }}>
            Remove Completed
          </button>
        </div>
      )}
    </div>
  );
}
