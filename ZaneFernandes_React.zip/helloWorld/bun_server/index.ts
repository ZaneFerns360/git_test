export interface Task {
  name: string;
  isDone: boolean;
}

export const tasks: Task[] = [
  { name: "Read Springboot", isDone: false },
  { name: "Complete Assignments", isDone: true },
  { name: "Prepare Breakfast", isDone: false },
  { name: "Sleep for 2 hours", isDone: false },
];

const server = Bun.serve({
  port: 3000,
  fetch(req) {
    const url = new URL(req.url);

    if (req.method === "OPTIONS") {
      return new Response("OK", {
        headers: {
          "Access-Control-Allow-Origin": "*", // Allow any origin
          "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
        },
      });
    }

    if (url.pathname === "/api/status") {
      return new Response("OK", {
        headers: { "Access-Control-Allow-Origin": "*" },
      });
    }

    if (url.pathname === "/api/todos") {
      return Response.json(tasks, {
        headers: { "Access-Control-Allow-Origin": "*" },
      });
    }

    return new Response("Not Found", { status: 404 });
  },
});

console.log(`Server running at ${server.url}`);
