package org.example;

import java.time.LocalDateTime;

public record Receipt(int receiptNo, int slotNo, int carNo, LocalDateTime parkingTime) {
}