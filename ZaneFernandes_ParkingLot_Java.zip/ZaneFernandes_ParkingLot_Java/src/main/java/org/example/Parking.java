package org.example;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

public class Parking implements ParkingLot {
    private final Map<Integer, Car> slots = new HashMap<>();
    private final Map<Integer, Receipt> receipts = new HashMap<>();
    private final int maxSlots;
    private int receiptCount;

    public Parking(int maxSlots) {
        this.maxSlots = maxSlots;
    }

    @Override
    public Receipt park(Car car, LocalDateTime enterTime) {
        if (slots.size() >= maxSlots) {
            throw new RuntimeException(ParkingErrors.PARKING_FULL_ERROR);
        }

        int slot = slots.size() + 1;
        receiptCount++;

        Receipt receipt = new Receipt(
                receiptCount,
                slot,
                car.carNo(),
                enterTime
        );

        slots.put(slot, car);
        receipts.put(receipt.receiptNo(), receipt);

        return receipt;
    }

    @Override
    public int unpark(LocalDateTime leaveTime, Receipt receipt) {
        if (!receipts.containsKey(receipt.receiptNo())) {
            throw new RuntimeException(ParkingErrors.INVALID_RECEIPT_ERROR);
        }

        Receipt storedReceipt = receipts.get(receipt.receiptNo());
        Duration duration = Duration.between(storedReceipt.parkingTime(), leaveTime);

        long days = duration.toHours() / 24;
        int fare = 100 + (int) days * 50;

        slots.remove(storedReceipt.slotNo());
        receipts.remove(receipt.receiptNo());

        return fare;
    }
}