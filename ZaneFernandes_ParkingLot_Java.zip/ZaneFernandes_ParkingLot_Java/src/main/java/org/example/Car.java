package org.example;

public record Car(int carNo) {
}