
package org.example;

public class ParkingErrors {
    public static final String PARKING_FULL_ERROR = "Parking lot is full";
    public static final String INVALID_RECEIPT_ERROR = "invalid receipt";
}