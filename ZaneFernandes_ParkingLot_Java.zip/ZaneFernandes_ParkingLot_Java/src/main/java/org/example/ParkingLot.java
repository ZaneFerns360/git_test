package org.example;

import java.time.LocalDateTime;

public interface ParkingLot {
    Receipt park(Car car, LocalDateTime enterTime);
    int unpark(LocalDateTime leaveTime, Receipt receipt);
}