package org.example;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.stream.Stream;

class ParkingTest {

    record ParkTestCase(
            String testCaseName,
            int maxSlots,
            Car car,
            boolean expectedToPark,
            String expectedErrorMessage
    ) {
        static ParkTestCase success(String name, int maxSlots, int carNo) {
            return new ParkTestCase(name, maxSlots, new Car(carNo), true, null);
        }

        static ParkTestCase failure(String name, int maxSlots, int carNo, String error) {
            return new ParkTestCase(name, maxSlots, new Car(carNo), false, error);
        }
    }

    static Stream<ParkTestCase> parkTableProvider() {
        return Stream.of(
                ParkTestCase.success("should park car successfully", 2, 1234),
                ParkTestCase.success("should park another car successfully", 2, 9999),
                ParkTestCase.failure("should fail to park when lot is full", 0, 9299, ParkingErrors.PARKING_FULL_ERROR)
        );
    }

    @ParameterizedTest
    @MethodSource("parkTableProvider")
    void Test_ParkTable(ParkTestCase tc) {
        Parking parking = new Parking(tc.maxSlots);
        LocalDateTime now = LocalDateTime.now();

        if (tc.expectedErrorMessage != null) {
            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                parking.park(tc.car, now);
            });
            assertEquals(tc.expectedErrorMessage, exception.getMessage());
        } else {
            Receipt receipt = assertDoesNotThrow(() -> parking.park(tc.car, now));
            assertEquals(tc.car.carNo(), receipt.carNo());
            assertTrue(receipt.slotNo() > 0);
        }
    }

    record UnparkTestCase(
            String testCaseName,
            long hoursParked,
            boolean useInvalidReceipt,
            int expectedCost,
            String expectedErrorMessage
    ) {
        static UnparkTestCase success(String name, long hours, int cost) {
            return new UnparkTestCase(name, hours, false, cost, null);
        }

        static UnparkTestCase failure(String name, long hours, String error) {
            return new UnparkTestCase(name, hours, true, 0, error);
        }
    }

    static Stream<UnparkTestCase> unparkTableProvider() {
        return Stream.of(
                UnparkTestCase.success("should unpark same day", 2, 100),
                UnparkTestCase.success("should unpark next day", 24, 150),
                UnparkTestCase.success("should unpark after two days", 48, 200),
                UnparkTestCase.failure("should fail unpark with invalid receipt", 1, ParkingErrors.INVALID_RECEIPT_ERROR)
        );
    }

    @ParameterizedTest
    @MethodSource("unparkTableProvider")
    void Test_UnparkTable(UnparkTestCase tc) {
        Parking parking = new Parking(10);
        LocalDateTime now = LocalDateTime.now();
        Receipt validReceipt = parking.park(new Car(1111), now);

        Receipt receiptToUse = tc.useInvalidReceipt
                ? new Receipt(999, 0, 0, now)
                : validReceipt;

        LocalDateTime leaveTime = now.plusHours(tc.hoursParked);

        if (tc.expectedErrorMessage != null) {
            RuntimeException exception = assertThrows(RuntimeException.class, () -> {
                parking.unpark(leaveTime, receiptToUse);
            });
            assertEquals(tc.expectedErrorMessage, exception.getMessage());
        } else {
            int cost = assertDoesNotThrow(() -> parking.unpark(leaveTime, receiptToUse));
            assertEquals(tc.expectedCost, cost);
        }
    }
}