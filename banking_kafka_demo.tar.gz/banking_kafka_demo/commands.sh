# ─── SETUP ───────────────────────────────────────────────────────────────
docker compose down -v
docker compose build --no-cache connect
docker compose up -d
docker compose logs -f connect   # wait until "Kafka Connect started", then Ctrl+C

# ─── CREATE TOPICS ───────────────────────────────────────────────────────
docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka:7.6.1" -q) \
  kafka-topics --bootstrap-server localhost:9092 --create --topic bank.transfers --partitions 3 --replication-factor 1

docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka:7.6.1" -q) \
  kafka-topics --bootstrap-server localhost:9092 --create --topic bank.notifications --partitions 3 --replication-factor 1

docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka:7.6.1" -q) \
  kafka-topics --bootstrap-server localhost:9092 --create --topic bank.dlq --partitions 3 --replication-factor 1

docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka:7.6.1" -q) \
  kafka-topics --bootstrap-server localhost:9092 --list

# ─── EXAMPLE A: FILE → KAFKA → FILE ──────────────────────────────────────

# Write first line to input file
docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka-connect:7.6.1" -q) bash -lc \
  "printf 'txn-100,{\"from\":\"john\",\"to\":\"jane\",\"amount\":250}\n' >> /tmp/input.txt"

# Create file source connector
curl -s -X POST http://localhost:8083/connectors \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "file-source-1",
    "config": {
      "connector.class": "org.apache.kafka.connect.file.FileStreamSourceConnector",
      "tasks.max": "1",
      "file": "/tmp/input.txt",
      "topic": "bank.transfers"
    }
  }' | jq .

# Append more lines
docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka-connect:7.6.1" -q) bash -lc \
  "echo 'txn-101,{\"from\":\"anil\",\"to\":\"sunita\",\"amount\":500}' >> /tmp/input.txt"

docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka-connect:7.6.1" -q) bash -lc \
  "echo 'txn-102,{\"from\":\"priya\",\"to\":\"raj\",\"amount\":999}' >> /tmp/input.txt"

# Verify messages in topic
docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka:7.6.1" -q) \
  kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic bank.transfers --from-beginning --max-messages 10

# Create file sink connector
curl -s -X POST http://localhost:8083/connectors \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "file-sink-1",
    "config": {
      "connector.class": "org.apache.kafka.connect.file.FileStreamSinkConnector",
      "tasks.max": "1",
      "topics": "bank.transfers",
      "file": "/tmp/output.txt"
    }
  }' | jq .

# Check sink is running
curl -s http://localhost:8083/connectors/file-sink-1/status | jq .

# Read sink output
docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka-connect:7.6.1" -q) bash -lc \
  "cat /tmp/output.txt"

# ─── EXAMPLE B: POSTGRES → KAFKA (JDBC SOURCE) ───────────────────────────

# Create table and seed rows
docker exec -it $(docker ps --filter "ancestor=postgres:15" -q) \
  psql -U bank -d bankdb -c "
    CREATE TABLE IF NOT EXISTS transfers (
      id         SERIAL PRIMARY KEY,
      from_acct  VARCHAR(50),
      to_acct    VARCHAR(50),
      amount     NUMERIC(12,2),
      created_at TIMESTAMP DEFAULT NOW()
    );
    INSERT INTO transfers(from_acct, to_acct, amount)
    VALUES ('alice','bob',100.00), ('geeta','rahul',300.50);
  "

# Create JDBC source connector
curl -s -X POST http://localhost:8083/connectors \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "jdbc-source-transfers",
    "config": {
      "connector.class": "io.confluent.connect.jdbc.JdbcSourceConnector",
      "tasks.max": "1",
      "connection.url": "jdbc:postgresql://localhost:5432/bankdb",
      "connection.user": "bank",
      "connection.password": "bankpw",
      "mode": "incrementing",
      "incrementing.column.name": "id",
      "table.whitelist": "transfers",
      "topic.prefix": "bank.",
      "poll.interval.ms": "3000"
    }
  }' | jq .

# Check connector status
curl -s http://localhost:8083/connectors/jdbc-source-transfers/status | jq .

# Watch rows stream into topic
docker exec -it $(docker ps --filter "ancestor=confluentinc/cp-kafka:7.6.1" -q) \
  kafka-console-consumer --bootstrap-server localhost:9092 \
  --topic bank.transfers --from-beginning

# Insert another row and watch it appear live (run in a second terminal)
docker exec -it $(docker ps --filter "ancestor=postgres:15" -q) \
  psql -U bank -d bankdb -c "
    INSERT INTO transfers(from_acct, to_acct, amount)
    VALUES ('vikram','asha',750.00);
  "
