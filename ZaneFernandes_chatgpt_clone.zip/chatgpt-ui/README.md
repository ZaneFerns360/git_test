# ChatGPT UI

A simple ChatGPT-style user interface built using modern frontend tools.

## Tech Stack

- **TypeScript** – Type-safe JavaScript for better maintainability  
- **React** – Component-based UI development  
- **Vite** – Fast build tool and development server  
- **Material Ui & CSS** – Custom styling  

## 📂 Project Structure

- `src/components` – UI components (Chat interface, Sidebar, Message bubbles)
- `src/utils` – Constants, state management and chat storage logic
- `src/types.ts` – TypeScript type definitions

## ▶️ Getting Started

Install dependencies:

```bash
bun install
# or
npm install
````

Run the development server:

```bash
bun run dev
# or
npm run dev
```

Build for production:

```bash
bun run build
# or
npm run build
```


# React + TypeScript + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) (or [oxc](https://oxc.rs) when used in [rolldown-vite](https://vite.dev/guide/rolldown)) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh

## React Compiler

The React Compiler is enabled on this template. See [this documentation](https://react.dev/learn/react-compiler) for more information.

Note: This will impact Vite dev & build performances.
