import React, { useState } from "react";
import { Menu, MenuItem } from "@mui/material";
import type { Conversation } from "../types";
import {
  IconNewChat,
  IconImages,
  IconApps,
  IconCodex,
  IconProjects,
  IconMenuOpen,
  IconMore,
  IconEdit,
  IconDelete,
  IconChat,
  OpenAILogoMark,
} from "../utils/icons";

const FEATURE_ITEMS = [
  { label: "Images", icon: <IconImages /> },
  { label: "Apps", icon: <IconApps /> },
  { label: "Codex", icon: <IconCodex /> },
  { label: "Projects", icon: <IconProjects /> },
];

function groupByDate(convs: Conversation[]) {
  const now = Date.now();
  const DAY = 86400000;
  const groups = [
    { label: "Today", items: [] as Conversation[] },
    { label: "Yesterday", items: [] as Conversation[] },
    { label: "Previous 7 Days", items: [] as Conversation[] },
    { label: "Older", items: [] as Conversation[] },
  ];
  for (const c of convs) {
    const age = now - c.updatedAt;
    if (age < DAY) groups[0].items.push(c);
    else if (age < 2 * DAY) groups[1].items.push(c);
    else if (age < 7 * DAY) groups[2].items.push(c);
    else groups[3].items.push(c);
  }
  return groups.filter((g) => g.items.length > 0);
}

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
}

export default function Sidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
  onRename,
}: Props) {
  const [menuAnchor, setMenuAnchor] = useState<null | HTMLElement>(null);
  const [menuConvId, setMenuConvId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const groups = groupByDate(conversations);

  function openMenu(e: React.MouseEvent<HTMLElement>, id: string) {
    e.stopPropagation();
    setMenuAnchor(e.currentTarget);
    setMenuConvId(id);
  }

  function closeMenu() {
    setMenuAnchor(null);
    setMenuConvId(null);
  }

  function startEdit(id: string, title: string) {
    setEditingId(id);
    setEditValue(title);
    closeMenu();
  }

  function commitEdit() {
    if (editingId && editValue.trim()) onRename(editingId, editValue.trim());
    setEditingId(null);
  }

  return (
    <div
      style={{
        width: 300,
        flexShrink: 0,
        height: "100%",
        display: "flex",
        flexDirection: "column",
        backgroundColor: "#171717",
        fontFamily: '"Inter", system-ui, sans-serif',
      }}
    >
      {/* Header */}
      <div style={{ padding: "14px 12px 4px" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: "0 6px",
            marginBottom: 10,
          }}
        >
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: "50%",
              backgroundColor: "white",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <OpenAILogoMark size={17} />
          </div>
          <button
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              color: "rgba(255,255,255,0.45)",
              padding: "6px",
              borderRadius: 8,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.color =
                "rgba(255,255,255,0.9)";
              (e.currentTarget as HTMLElement).style.background = "#2a2a2a";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.color =
                "rgba(255,255,255,0.45)";
              (e.currentTarget as HTMLElement).style.background = "none";
            }}
          >
            <IconMenuOpen />
          </button>
        </div>

        {/* Nav  */}
        {[
          { label: "New chat", icon: <IconNewChat />, onClick: onNew },
          ...FEATURE_ITEMS,
        ].map((item) => (
          <button
            key={item.label}
            onClick={"onClick" in item ? item.onClick : undefined}
            style={{
              width: "100%",
              background: "none",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 12,
              padding: "8px 14px",
              borderRadius: 10,
              color: "rgba(255,255,255,0.9)",
              fontSize: 15,
              fontWeight: 500,
              fontFamily: "inherit",
              letterSpacing: "-0.01em",
              marginBottom: 2,
            }}
            onMouseEnter={(e) => (e.currentTarget.style.background = "#2a2a2a")}
            onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </div>

      <div
        style={{
          borderTop: "1px solid rgba(255,255,255,0.07)",
          margin: "6px 0",
        }}
      />

      {/* Conversation list */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0 6px" }}>
        {groups.length === 0 ? (
          <div style={{ padding: 24, textAlign: "center" }}>
            <div
              style={{
                color: "rgba(255,255,255,0.15)",
                marginBottom: 8,
                display: "flex",
                justifyContent: "center",
              }}
            >
              <IconChat />
            </div>
            <span style={{ color: "rgba(255,255,255,0.25)", fontSize: 13 }}>
              No chats yet
            </span>
          </div>
        ) : (
          groups.map((group) => (
            <div key={group.label}>
              <div
                style={{
                  padding: "16px 8px 6px",
                  fontSize: 12,
                  fontWeight: 600,
                  textTransform: "uppercase",
                  letterSpacing: "0.08em",
                  color: "rgba(255,255,255,0.35)",
                }}
              >
                {group.label}
              </div>

              {group.items.map((conv) => (
                <div
                  key={conv.id}
                  style={{ position: "relative", marginBottom: 2 }}
                  onMouseEnter={() => setHoveredId(conv.id)}
                  onMouseLeave={() => setHoveredId(null)}
                >
                  {editingId === conv.id ? (
                    <div style={{ padding: "2px 4px" }}>
                      <input
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onBlur={commitEdit}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") commitEdit();
                          if (e.key === "Escape") setEditingId(null);
                        }}
                        autoFocus
                        style={{
                          width: "100%",
                          background: "#2a2a2a",
                          border: "1px solid rgba(255,255,255,0.2)",
                          borderRadius: 8,
                          padding: "6px 10px",
                          color: "white",
                          fontSize: 14,
                          fontFamily: "inherit",
                          outline: "none",
                          boxSizing: "border-box",
                        }}
                      />
                    </div>
                  ) : (
                    <>
                      <button
                        onClick={() => onSelect(conv.id)}
                        style={{
                          width: "100%",
                          background: conv.id === activeId ? "#2a2a2a" : "none",
                          border: "none",
                          cursor: "pointer",
                          textAlign: "left",
                          padding: "8px 14px",
                          paddingRight: hoveredId === conv.id ? 36 : 14,
                          borderRadius: 10,
                          color:
                            conv.id === activeId
                              ? "white"
                              : "rgba(255,255,255,0.88)",
                          fontSize: 15,
                          fontWeight: conv.id === activeId ? 600 : 500,
                          fontFamily: "inherit",
                          letterSpacing: "-0.01em",
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          transition: "background 0.1s",
                        }}
                        onMouseEnter={(e) => {
                          if (conv.id !== activeId)
                            e.currentTarget.style.background = "#242424";
                        }}
                        onMouseLeave={(e) => {
                          if (conv.id !== activeId)
                            e.currentTarget.style.background = "none";
                        }}
                      >
                        {conv.title}
                      </button>

                      {hoveredId === conv.id && (
                        <button
                          onClick={(e) => openMenu(e, conv.id)}
                          style={{
                            position: "absolute",
                            right: 6,
                            top: "50%",
                            transform: "translateY(-50%)",
                            background: "none",
                            border: "none",
                            cursor: "pointer",
                            color: "rgba(255,255,255,0.45)",
                            padding: "4px",
                            borderRadius: 6,
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.color = "white";
                            e.currentTarget.style.background =
                              "rgba(255,255,255,0.08)";
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.color =
                              "rgba(255,255,255,0.45)";
                            e.currentTarget.style.background = "none";
                          }}
                        >
                          <IconMore />
                        </button>
                      )}
                    </>
                  )}
                </div>
              ))}
            </div>
          ))
        )}
      </div>

      {/* Context menu */}
      <Menu
        anchorEl={menuAnchor}
        open={Boolean(menuAnchor)}
        onClose={closeMenu}
        PaperProps={{
          sx: {
            bgcolor: "#2a2a2a",
            border: "1px solid rgba(255,255,255,0.1)",
            borderRadius: "10px",
            minWidth: 160,
            boxShadow: "0 8px 24px rgba(0,0,0,0.5)",
          },
        }}
      >
        <MenuItem
          onClick={() => {
            const c = conversations.find((x) => x.id === menuConvId);
            if (c) startEdit(c.id, c.title);
          }}
          sx={{
            fontSize: 14,
            fontWeight: 500,
            color: "rgba(255,255,255,0.85)",
            gap: 1.5,
            py: 1,
            fontFamily: "inherit",
          }}
        >
          <span style={{ color: "rgba(255,255,255,0.45)", display: "flex" }}>
            <IconEdit />
          </span>
          Rename
        </MenuItem>
        <MenuItem
          onClick={() => {
            if (menuConvId) onDelete(menuConvId);
            closeMenu();
          }}
          sx={{
            fontSize: 14,
            fontWeight: 500,
            color: "#f87171",
            gap: 1.5,
            py: 1,
            fontFamily: "inherit",
          }}
        >
          <span style={{ display: "flex" }}>
            <IconDelete />
          </span>
          Delete
        </MenuItem>
      </Menu>

      {/* Footer */}
      <div
        style={{ borderTop: "1px solid rgba(255,255,255,0.07)", padding: 12 }}
      >
        <button
          style={{
            width: "100%",
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 12,
            padding: "7px 14px",
            borderRadius: 10,
            fontFamily: "inherit",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "#2a2a2a")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "none")}
        >
          <div
            style={{
              width: 30,
              height: 30,
              borderRadius: "50%",
              background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 13,
              fontWeight: 700,
              color: "white",
              flexShrink: 0,
            }}
          >
            U
          </div>
          <span
            style={{
              fontSize: 15,
              fontWeight: 500,
              letterSpacing: "-0.01em",
              color: "rgba(255,255,255,0.85)",
            }}
          >
            User
          </span>
        </button>
      </div>
    </div>
  );
}
