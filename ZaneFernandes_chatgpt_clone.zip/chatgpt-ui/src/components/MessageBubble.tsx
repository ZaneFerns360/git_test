import React from "react";
import { Box, Typography, Avatar } from "@mui/material";
import SmartToyOutlinedIcon from "@mui/icons-material/SmartToyOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import type { Message } from "../types";

interface Props {
  message: Message;
  isLatest?: boolean;
  isStreaming?: boolean;
}

function renderContent(content: string) {
  // Simple markdown rendering: bold, code blocks, inline code
  const lines = content.split("\n");
  const result: React.ReactNode[] = [];
  let inCode = false;
  let codeLines: string[] = [];
  let codeLang = "";

  lines.forEach((line, i) => {
    if (line.startsWith("```")) {
      if (!inCode) {
        inCode = true;
        codeLang = line.slice(3).trim();
        codeLines = [];
      } else {
        inCode = false;
        result.push(
          <Box
            key={i}
            sx={{
              my: 1.5,
              bgcolor: "#0d0d0d",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "8px",
              overflow: "hidden",
            }}
          >
            {codeLang && (
              <Box
                sx={{
                  px: 2,
                  py: 0.75,
                  bgcolor: "rgba(255,255,255,0.05)",
                  borderBottom: "1px solid rgba(255,255,255,0.07)",
                }}
              >
                <Typography
                  sx={{
                    fontSize: 11,
                    color: "rgba(255,255,255,0.4)",
                    fontFamily: "monospace",
                  }}
                >
                  {codeLang}
                </Typography>
              </Box>
            )}
            <Box sx={{ p: 2, overflowX: "auto" }}>
              <Typography
                component="pre"
                sx={{
                  fontSize: 13,
                  lineHeight: 1.6,
                  color: "#e2e8f0",
                  fontFamily: '"Fira Code", "Cascadia Code", monospace',
                  whiteSpace: "pre",
                  m: 0,
                }}
              >
                {codeLines.join("\n")}
              </Typography>
            </Box>
          </Box>,
        );
        codeLines = [];
      }
      return;
    }

    if (inCode) {
      codeLines.push(line);
      return;
    }

    if (line === "") {
      result.push(<Box key={i} sx={{ height: 8 }} />);
      return;
    }

    // Parse inline formatting: **bold**, `code`
    const parts: React.ReactNode[] = [];
    let remaining = line;
    let partKey = 0;

    while (remaining.length > 0) {
      const boldIdx = remaining.indexOf("**");
      const codeIdx = remaining.indexOf("`");

      if (boldIdx === -1 && codeIdx === -1) {
        parts.push(<span key={partKey++}>{remaining}</span>);
        break;
      }

      const firstIdx =
        boldIdx === -1
          ? codeIdx
          : codeIdx === -1
            ? boldIdx
            : Math.min(boldIdx, codeIdx);

      if (firstIdx > 0) {
        parts.push(<span key={partKey++}>{remaining.slice(0, firstIdx)}</span>);
        remaining = remaining.slice(firstIdx);
        continue;
      }

      if (remaining.startsWith("**")) {
        const end = remaining.indexOf("**", 2);
        if (end !== -1) {
          parts.push(
            <strong key={partKey++}>{remaining.slice(2, end)}</strong>,
          );
          remaining = remaining.slice(end + 2);
        } else {
          parts.push(<span key={partKey++}>**</span>);
          remaining = remaining.slice(2);
        }
      } else if (remaining.startsWith("`")) {
        const end = remaining.indexOf("`", 1);
        if (end !== -1) {
          parts.push(
            <Box
              key={partKey++}
              component="code"
              sx={{
                bgcolor: "rgba(255,255,255,0.12)",
                px: 0.6,
                py: 0.1,
                borderRadius: "4px",
                fontSize: "0.88em",
                fontFamily: "monospace",
                color: "#93c5fd",
              }}
            >
              {remaining.slice(1, end)}
            </Box>,
          );
          remaining = remaining.slice(end + 1);
        } else {
          parts.push(<span key={partKey++}>`</span>);
          remaining = remaining.slice(1);
        }
      }
    }

    result.push(
      <Typography
        key={i}
        sx={{ fontSize: 15, lineHeight: 1.75, color: "rgba(255,255,255,0.9)" }}
      >
        {parts}
      </Typography>,
    );
  });

  return result;
}

export default function MessageBubble({
  message,
  isLatest,
  isStreaming,
}: Props) {
  const isUser = message.role === "user";

  return (
    <Box
      className={isLatest ? "message-enter" : undefined}
      sx={{
        display: "flex",
        gap: 2,
        px: { xs: 2, md: 4 },
        py: 2.5,
        bgcolor: isUser ? "transparent" : "rgba(255,255,255,0.02)",
        borderBottom: "1px solid rgba(255,255,255,0.04)",
        alignItems: "flex-start",
        maxWidth: 820,
        mx: "auto",
        width: "100%",
      }}
    >
      <Avatar
        sx={{
          width: 32,
          height: 32,
          flexShrink: 0,
          mt: 0.25,
          bgcolor: isUser ? "rgba(99,102,241,0.8)" : "rgba(16,163,127,0.85)",
          border: `1.5px solid ${isUser ? "rgba(99,102,241,0.4)" : "rgba(16,163,127,0.4)"}`,
        }}
      >
        {isUser ? (
          <PersonOutlineIcon sx={{ fontSize: 17 }} />
        ) : (
          <SmartToyOutlinedIcon sx={{ fontSize: 17 }} />
        )}
      </Avatar>

      <Box sx={{ flex: 1, minWidth: 0 }}>
        <Typography
          sx={{
            fontSize: 12,
            fontWeight: 600,
            color: "rgba(255,255,255,0.4)",
            mb: 0.75,
            fontFamily: '"DM Sans", sans-serif',
            letterSpacing: "0.3px",
          }}
        >
          {isUser ? "You" : "ChatClone"}
        </Typography>
        <Box>
          {renderContent(message.content)}
          {isStreaming && <span className="cursor-blink" />}
        </Box>
      </Box>
    </Box>
  );
}
