import React, { useState, useRef, useEffect } from "react";
import { Tooltip } from "@mui/material";
import type { Conversation } from "../types";
import { getAIResponse } from "../utils/responses";
import {
  AudioWaveIcon,
  MicIcon,
  OpenAILogoMark,
  IconNewChat,
  IconAttach,
  IconSend,
  IconStop,
  IconPerson,
} from "../utils/icons";

function renderContent(content: string) {
  const lines = content.split("\n");
  const result: React.ReactNode[] = [];
  let inCode = false;
  let codeLines: string[] = [];
  let codeLang = "";

  lines.forEach((line, i) => {
    if (line.startsWith("```")) {
      if (!inCode) {
        inCode = true;
        codeLang = line.slice(3).trim();
        codeLines = [];
      } else {
        inCode = false;
        result.push(
          <div
            key={`code-${i}`}
            style={{
              margin: "12px 0",
              background: "#0d0d0d",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 10,
              overflow: "hidden",
            }}
          >
            {codeLang && (
              <div
                style={{
                  padding: "6px 16px",
                  background: "rgba(255,255,255,0.05)",
                  borderBottom: "1px solid rgba(255,255,255,0.07)",
                }}
              >
                <span
                  style={{
                    fontSize: 11,
                    color: "rgba(255,255,255,0.4)",
                    fontFamily: "monospace",
                  }}
                >
                  {codeLang}
                </span>
              </div>
            )}
            <div style={{ padding: 16, overflowX: "auto" }}>
              <pre
                style={{
                  fontSize: 13.5,
                  lineHeight: 1.65,
                  color: "#e2e8f0",
                  fontFamily:
                    'ui-monospace, "SFMono-Regular", Menlo, Monaco, Consolas, monospace',
                  whiteSpace: "pre",
                  margin: 0,
                }}
              >
                {codeLines.join("\n")}
              </pre>
            </div>
          </div>,
        );
        codeLines = [];
      }
      return;
    }
    if (inCode) {
      codeLines.push(line);
      return;
    }
    if (line === "") {
      result.push(<div key={`sp-${i}`} style={{ height: 8 }} />);
      return;
    }

    const parts: React.ReactNode[] = [];
    let rem = line;
    let pk = 0;
    while (rem.length > 0) {
      const bi = rem.indexOf("**"),
        ci = rem.indexOf("`");
      if (bi === -1 && ci === -1) {
        parts.push(<span key={pk++}>{rem}</span>);
        break;
      }
      const fi = bi === -1 ? ci : ci === -1 ? bi : Math.min(bi, ci);
      if (fi > 0) {
        parts.push(<span key={pk++}>{rem.slice(0, fi)}</span>);
        rem = rem.slice(fi);
        continue;
      }
      if (rem.startsWith("**")) {
        const end = rem.indexOf("**", 2);
        if (end !== -1) {
          parts.push(<strong key={pk++}>{rem.slice(2, end)}</strong>);
          rem = rem.slice(end + 2);
        } else {
          parts.push(<span key={pk++}>**</span>);
          rem = rem.slice(2);
        }
      } else if (rem.startsWith("`")) {
        const end = rem.indexOf("`", 1);
        if (end !== -1) {
          parts.push(
            <code
              key={pk++}
              style={{
                background: "rgba(255,255,255,0.1)",
                padding: "1px 5px",
                borderRadius: 4,
                fontSize: "0.88em",
                fontFamily: "monospace",
                color: "#93c5fd",
              }}
            >
              {rem.slice(1, end)}
            </code>,
          );
          rem = rem.slice(end + 1);
        } else {
          parts.push(<span key={pk++}>`</span>);
          rem = rem.slice(1);
        }
      }
    }
    result.push(
      <p
        key={`ln-${i}`}
        style={{
          fontSize: 16,
          lineHeight: 1.8,
          color: "rgba(255,255,255,0.92)",
          margin: 0,
        }}
      >
        {parts}
      </p>,
    );
  });
  return result;
}

const SUGGESTIONS = [
  { emoji: "🖼️", label: "Create images" },
  { emoji: "📖", label: "Learn something" },
  { emoji: "✏️", label: "Write or edit" },
  { emoji: "💡", label: "How-to help" },
];

// small reusable icon button
function IconBtn({
  onClick,
  title,
  children,
  style,
}: {
  onClick?: () => void;
  title: string;
  children: React.ReactNode;
  style?: React.CSSProperties;
}) {
  const [hovered, setHovered] = useState(false);
  return (
    <Tooltip title={title}>
      <button
        onClick={onClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          background: hovered ? "rgba(255,255,255,0.07)" : "none",
          border: "none",
          cursor: "pointer",
          borderRadius: "50%",
          padding: 7,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: hovered ? "white" : "rgba(255,255,255,0.55)",
          flexShrink: 0,
          transition: "background 0.15s, color 0.15s",
          ...style,
        }}
      >
        {children}
      </button>
    </Tooltip>
  );
}

interface Props {
  conversation: Conversation | null;
  onUserMessage: (convId: string, msg: string) => void;
  onAiResponse: (convId: string, msg: string) => void;
  onNewChat: () => string;
}

export default function ChatInterface({
  conversation,
  onUserMessage,
  onAiResponse,
  onNewChat,
}: Props) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [streamingText, setStreamingText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef(false);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversation?.messages, streamingText]);

  // Auto-resize for textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (!el) return;
    el.style.height = "auto";
    el.style.height = Math.min(el.scrollHeight, 200) + "px";
  }, [input]);

  const handleSend = async (text?: string) => {
    const msg = (text ?? input).trim();
    if (!msg || loading) return;

    setInput("");
    setLoading(true);
    abortRef.current = false;

    const convId = conversation?.id ?? onNewChat();
    onUserMessage(convId, msg);

    const aiText = await getAIResponse(msg);

    if (!abortRef.current) {
      onAiResponse(convId, aiText);
    }

    setLoading(false);
  };

  const messages = conversation?.messages ?? [];
  const isEmpty = messages.length === 0 && !streamingText && !loading;

  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        background: "#212121",
        overflow: "hidden",
        fontFamily:
          '"Inter", system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
      }}
    >
      {/* Header */}
      <div
        style={{
          padding: "10px 24px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: isEmpty ? "none" : "1px solid rgba(255,255,255,0.06)",
          flexShrink: 0,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span
            style={{
              fontSize: 16,
              fontWeight: 600,
              color: "rgba(255,255,255,0.92)",
              letterSpacing: "-0.01em",
            }}
          >
            ChatGPT
          </span>
          <span
            style={{
              color: "rgba(255,255,255,0.35)",
              fontSize: 18,
              lineHeight: 1,
            }}
          >
            ⌄
          </span>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          <IconBtn title="Account" style={{ borderRadius: 8 }}>
            <IconPerson />
          </IconBtn>
          <IconBtn
            title="New chat"
            onClick={() => onNewChat()}
            style={{ borderRadius: 8 }}
          >
            <IconNewChat />
          </IconBtn>
        </div>
      </div>

      {/* Messages */}
      <div
        style={{
          flex: 1,
          overflowY: "auto",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {isEmpty ? (
          <div
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 32,
              padding: "0 24px 96px",
            }}
          >
            <p
              style={{
                fontSize: 32,
                fontWeight: 600,
                color: "rgba(255,255,255,0.92)",
                textAlign: "center",
                letterSpacing: "-0.5px",
                margin: 0,
              }}
            >
              What's on your mind today?
            </p>
          </div>
        ) : (
          <div>
            {messages.map((msg, idx) => (
              <div
                key={msg.id}
                className={
                  idx === messages.length - 1 ? "message-enter" : undefined
                }
                style={{
                  padding: "24px 48px",
                  maxWidth: 780,
                  margin: "0 auto",
                  width: "100%",
                  display: "flex",
                  gap: 20,
                  alignItems: "flex-start",
                  boxSizing: "border-box",
                }}
              >
                {/* Avatar */}
                {msg.role === "assistant" ? (
                  <div
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: "50%",
                      background: "white",
                      flexShrink: 0,
                      marginTop: 2,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <OpenAILogoMark size={16} />
                  </div>
                ) : (
                  <div
                    style={{
                      width: 30,
                      height: 30,
                      borderRadius: "50%",
                      background: "linear-gradient(135deg, #7c3aed, #4f46e5)",
                      flexShrink: 0,
                      marginTop: 2,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 13,
                      fontWeight: 700,
                      color: "white",
                    }}
                  >
                    U
                  </div>
                )}
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p
                    style={{
                      fontSize: 14,
                      fontWeight: 600,
                      marginBottom: 6,
                      marginTop: 0,
                      color: "rgba(255,255,255,0.4)",
                      letterSpacing: "-0.01em",
                    }}
                  >
                    {msg.role === "user" ? "You" : "ChatGPT"}
                  </p>
                  {renderContent(msg.content)}
                </div>
              </div>
            ))}

            {(streamingText || loading) && (
              <div
                className="message-enter"
                style={{
                  padding: "24px 48px",
                  maxWidth: 780,
                  margin: "0 auto",
                  width: "100%",
                  display: "flex",
                  gap: 20,
                  alignItems: "flex-start",
                  boxSizing: "border-box",
                }}
              >
                <div
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: "50%",
                    background: "white",
                    flexShrink: 0,
                    marginTop: 2,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <OpenAILogoMark size={16} />
                </div>
                <div style={{ flex: 1, paddingTop: 2 }}>
                  <p
                    style={{
                      fontSize: 14,
                      fontWeight: 600,
                      marginBottom: 6,
                      marginTop: 0,
                      color: "rgba(255,255,255,0.4)",
                    }}
                  >
                    ChatGPT
                  </p>
                  {streamingText ? (
                    <div>
                      {renderContent(streamingText)}
                      <span className="cursor-blink" />
                    </div>
                  ) : (
                    <div
                      style={{
                        display: "flex",
                        gap: 5,
                        alignItems: "center",
                        paddingTop: 4,
                      }}
                    >
                      {[0, 1, 2].map((j) => (
                        <div
                          key={j}
                          style={{
                            width: 6,
                            height: 6,
                            borderRadius: "50%",
                            background: "rgba(255,255,255,0.5)",
                            animation: "dotPulse 1.2s ease-in-out infinite",
                            animationDelay: `${j * 0.2}s`,
                          }}
                        />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>
        )}
      </div>

      {/* Input area */}
      <div style={{ flexShrink: 0, padding: "0 40px 20px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          {/* Pill input */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 4,
              background: "#2f2f2f",
              borderRadius: 9999,
              border: "1px solid rgba(255,255,255,0.08)",
              padding: "6px 8px",
              transition: "border-color 0.15s, box-shadow 0.15s",
            }}
            onFocus={() => {}} // focus-within handled via CSS in App.css
          >
            <IconBtn title="Attach">
              <IconAttach />
            </IconBtn>

            <textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask anything"
              rows={1}
              style={{
                flex: 1,
                background: "transparent",
                border: "none",
                outline: "none",
                resize: "none",
                color: "rgba(255,255,255,0.97)",
                fontSize: 17,
                fontWeight: 400,
                lineHeight: 1.55,
                fontFamily:
                  '"Inter", system-ui, -apple-system, BlinkMacSystemFont, sans-serif',
                overflowY: "hidden",
                maxHeight: 180,
                padding: "3px 2px",
              }}
            />

            <IconBtn title="Voice input">
              <MicIcon />
            </IconBtn>

            {loading ? (
              <Tooltip title="Stop">
                <button
                  onClick={() => {
                    abortRef.current = true;
                    setLoading(false);
                    setStreamingText("");
                  }}
                  style={{
                    background: "white",
                    border: "none",
                    cursor: "pointer",
                    width: 36,
                    height: 36,
                    borderRadius: "50%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#1a1a1a",
                    flexShrink: 0,
                  }}
                >
                  <IconStop />
                </button>
              </Tooltip>
            ) : input.trim() ? (
              <button
                onClick={() => handleSend()}
                style={{
                  background: "white",
                  border: "none",
                  cursor: "pointer",
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#1a1a1a",
                  flexShrink: 0,
                  transition: "background 0.15s",
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "rgba(255,255,255,0.85)")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.background = "white")
                }
              >
                <IconSend />
              </button>
            ) : (
              <button
                style={{
                  background: "#676767",
                  border: "none",
                  cursor: "pointer",
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "white",
                  flexShrink: 0,
                }}
                onMouseEnter={(e) =>
                  (e.currentTarget.style.background = "#757575")
                }
                onMouseLeave={(e) =>
                  (e.currentTarget.style.background = "#676767")
                }
              >
                <AudioWaveIcon />
              </button>
            )}
          </div>

          {isEmpty && (
            <div
              style={{
                display: "flex",
                gap: 8,
                marginTop: 16,
                flexWrap: "wrap",
                justifyContent: "center",
              }}
            >
              {SUGGESTIONS.map((s) => (
                <button
                  key={s.label}
                  onClick={() => handleSend(s.label)}
                  style={{
                    background: "#2f2f2f",
                    border: "1px solid rgba(255,255,255,0.09)",
                    borderRadius: 9999,
                    padding: "0 16px",
                    height: 38,
                    fontSize: 14,
                    fontWeight: 500,
                    color: "rgba(255,255,255,0.8)",
                    cursor: "pointer",
                    letterSpacing: "-0.01em",
                    transition: "all 0.12s",
                    fontFamily: "inherit",
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.background = "#3a3a3a";
                    e.currentTarget.style.color = "white";
                    e.currentTarget.style.borderColor =
                      "rgba(255,255,255,0.18)";
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.background = "#2f2f2f";
                    e.currentTarget.style.color = "rgba(255,255,255,0.8)";
                    e.currentTarget.style.borderColor =
                      "rgba(255,255,255,0.09)";
                  }}
                >
                  {s.emoji}&nbsp;&nbsp;{s.label}
                </button>
              ))}
            </div>
          )}

          <p
            style={{
              textAlign: "center",
              marginTop: 14,
              fontSize: 13,
              fontWeight: 400,
              color: "rgba(255,255,255,0.28)",
              letterSpacing: "-0.01em",
            }}
          >
            ChatGPT can make mistakes. Consider checking important information.
          </p>
        </div>
      </div>
    </div>
  );
}
