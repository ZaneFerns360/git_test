const responses: Record<string, string> = {
  default: `I'm a clone of ChatGPT built with React.

Try asking me anything`,

  hello: `Hello! Great to meet you. I'm here and ready to help. What's on your mind today?`,

  hi: `Hey there! How can I help you today?`,

  help: `Sure, I can help with a wide range of tasks:

- **Writing & editing** — drafting emails, essays, reports
- **Coding** — debugging, explaining code, writing functions  
- **Research** — summarizing topics, answering questions
- **Brainstorming** — ideas, outlines, plans
- **Math & analysis** — calculations, data interpretation

What would you like to work on?`,

  code: `Here's a simple example in TypeScript:

\`\`\`typescript
function greet(name: string): string {
  return \`Hello, \${name}! Welcome to the demo.\`;
}

const message = greet("World");
console.log(message); // Hello, World! Welcome to the demo.
\`\`\`

Want me to explain how this works, or would you like me to write something specific?`,

  thanks: `You're welcome! Let me know if there's anything else I can help with.`,

  weather: `I don't have access to real-time data, so I can't check the current weather.Is there something else I can help you with?`,

  react: `React is a JavaScript library for building user interfaces, developed and maintained by Meta. Here are some key concepts:

**Components** — Reusable pieces of UI, written as functions or classes.

**JSX** — A syntax extension that lets you write HTML-like code inside JavaScript.

**State & Props** — State is local data a component manages. Props are inputs passed from parent to child.

**Hooks** — Functions like \`useState\` and \`useEffect\` that let you use React features in function components.

`,
};

function matchResponse(input: string): string {
  const lower = input.toLowerCase().trim();

  if (/^(hi|hey|hello)\b/.test(lower)) return responses.hi;
  if (/thank/.test(lower)) return responses.thanks;
  if (/help/.test(lower)) return responses.help;
  if (/weather|forecast/.test(lower)) return responses.weather;
  if (/code|javascript|python|programming/.test(lower)) return responses.code;
  if (/react/.test(lower)) return responses.react;

  return responses.default;
}

export async function getAIResponse(userMessage: string): Promise<string> {
  //   delay
  await new Promise((r) => setTimeout(r, 800 + Math.random() * 800));
  return matchResponse(userMessage);
}
