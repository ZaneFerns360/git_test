import { createTheme } from "@mui/material";
// openai color schemes
export const theme = createTheme({
  palette: {
    mode: "dark",
    background: { default: "#212121", paper: "#303030" },
    primary: { main: "#10a37f" },
  },
  typography: {
    fontFamily:
      '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        "*": { boxSizing: "border-box" },
        "html, body, #root": { height: "100%", margin: 0, padding: 0 },
      },
    },
    MuiListItemButton: {
      styleOverrides: {
        root: { transition: "background-color 0.12s" },
      },
    },
  },
});
