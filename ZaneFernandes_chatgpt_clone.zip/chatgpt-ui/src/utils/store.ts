import { useState } from "react";
import type { Conversation, Message } from "../types";
import { ACTIVE_KEY } from "./constants";
import { STORAGE_KEY } from "./constants";

function generateId() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function loadConversations(): Conversation[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function useStore() {
  const [conversations, setConversations] =
    useState<Conversation[]>(loadConversations);
  const [activeId, setActiveId] = useState<string | null>(() =>
    localStorage.getItem(ACTIVE_KEY),
  );

  const activeConversation =
    conversations.find((c) => c.id === activeId) ?? null;

  function saveConversations(convs: Conversation[]) {
    setConversations(convs);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(convs));
  }

  function setActive(id: string | null) {
    setActiveId(id);
    if (id) localStorage.setItem(ACTIVE_KEY, id);
    else localStorage.removeItem(ACTIVE_KEY);
  }

  function createConversation() {
    const id = generateId();
    const conv: Conversation = {
      id,
      title: "New chat",
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    saveConversations([conv, ...conversations]);
    setActive(id);
    return id;
  }

  function deleteConversation(id: string) {
    const next = conversations.filter((c) => c.id !== id);
    saveConversations(next);
    if (activeId === id) setActive(next[0]?.id ?? null);
  }

  function addMessage(convId: string, msg: Omit<Message, "id" | "timestamp">) {
    const newMessage: Message = {
      ...msg,
      id: generateId(),
      timestamp: Date.now(),
    };

    setConversations((prev) => {
      const updated = prev.map((c) => {
        if (c.id !== convId) return c;
        const isFirstMessage = c.messages.length === 0 && msg.role === "user";
        const title = isFirstMessage
          ? msg.content.slice(0, 40) + (msg.content.length > 40 ? "…" : "")
          : c.title;
        return {
          ...c,
          title,
          messages: [...c.messages, newMessage],
          updatedAt: Date.now(),
        };
      });
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });

    return newMessage;
  }

  function renameConversation(id: string, title: string) {
    saveConversations(
      conversations.map((c) => (c.id === id ? { ...c, title } : c)),
    );
  }

  return {
    conversations,
    activeId,
    activeConversation,
    setActive,
    createConversation,
    deleteConversation,
    addMessage,
    renameConversation,
  };
}
