export const STORAGE_KEY = "conversations";
export const ACTIVE_KEY = "clone_active";
