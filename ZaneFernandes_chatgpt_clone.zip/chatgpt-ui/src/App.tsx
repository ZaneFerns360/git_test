import React, { useCallback } from "react";
import {
  ThemeProvider,
  CssBaseline,
  Box,
  IconButton,
  Drawer,
  useMediaQuery,
  Tooltip,
} from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import "./App.css";
import Sidebar from "./components/Sidebar";
import ChatInterface from "./components/ChatInterface";
import { useStore } from "./utils/store";
import { theme } from "./utils/theme";

export default function App() {
  const store = useStore();
  const isMobile = useMediaQuery("(max-width:768px)");
  const [drawerOpen, setDrawerOpen] = React.useState(false);

  const handleUserMessage = useCallback(
    (convId: string, msg: string) => {
      store.addMessage(convId, { role: "user", content: msg });
    },
    [store],
  );

  const handleAiResponse = useCallback(
    (convId: string, msg: string) => {
      store.addMessage(convId, { role: "assistant", content: msg });
    },
    [store],
  );

  const handleNewChat = useCallback(() => {
    const id = store.createConversation();
    if (isMobile) setDrawerOpen(false);
    return id;
  }, [store, isMobile]);

  const handleSelect = useCallback(
    (id: string) => {
      store.setActive(id);
      if (isMobile) setDrawerOpen(false);
    },
    [store, isMobile],
  );

  const sidebarContent = (
    <Sidebar
      conversations={store.conversations}
      activeId={store.activeId}
      onSelect={handleSelect}
      onNew={handleNewChat}
      onDelete={store.deleteConversation}
      onRename={store.renameConversation}
    />
  );

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Box
        sx={{
          display: "flex",
          height: "100vh",
          width: "100vw",
          overflow: "hidden",
        }}
      >
        {isMobile ? (
          <>
            <Drawer
              open={drawerOpen}
              onClose={() => setDrawerOpen(false)}
              PaperProps={{
                sx: { bgcolor: "#171717", border: "none", width: 300 },
              }}
            >
              {sidebarContent}
            </Drawer>
            {/* Mobile menu to open */}
            <Box
              sx={{
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                zIndex: 1200,
                display: "flex",
                alignItems: "center",
                px: 1,
                py: 0.75,
                bgcolor: "#212121",
                borderBottom: "1px solid rgba(255,255,255,0.07)",
              }}
            >
              <Tooltip title="Menu">
                <IconButton
                  onClick={() => setDrawerOpen(true)}
                  sx={{
                    color: "rgba(255,255,255,0.6)",
                    "&:hover": { color: "white" },
                  }}
                >
                  <MenuIcon sx={{ fontSize: 20 }} />
                </IconButton>
              </Tooltip>
            </Box>
          </>
        ) : (
          sidebarContent
        )}

        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            pt: isMobile ? "48px" : 0,
          }}
        >
          <ChatInterface
            conversation={store.activeConversation}
            onUserMessage={handleUserMessage}
            onAiResponse={handleAiResponse}
            onNewChat={handleNewChat}
          />{" "}
        </Box>
      </Box>
    </ThemeProvider>
  );
}
