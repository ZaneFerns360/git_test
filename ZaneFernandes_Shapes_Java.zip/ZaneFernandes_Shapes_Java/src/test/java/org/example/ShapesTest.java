package org.example;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.Stream;

class ShapesTest {

    record ShapeTestCase(
            String testCaseName,
            double dimensionOne,   // Length (Rectangle) or Side (Square)
            double dimensionTwo,   // Breadth (Rectangle only, ignored for Square)
            double expectedPerimeter,
            double expectedArea,
            String expectedErrorMessage // If not null, we expect an error
    ) {
        static ShapeTestCase rectangleSuccess(String name, double length, double breadth, double perimeter, double area) {
            return new ShapeTestCase(name, length, breadth, perimeter, area, null);
        }

        static ShapeTestCase squareSuccess(String name, double side, double perimeter, double area) {
            return new ShapeTestCase(name, side, 0, perimeter, area, null);
        }

        static ShapeTestCase failure(String name, double dim1, double dim2, String error) {
            return new ShapeTestCase(name, dim1, dim2, 0, 0, error);
        }
    }

    static Stream<ShapeTestCase> rectangleTableProvider() {
        return Stream.of(

                ShapeTestCase.rectangleSuccess("Should create a Standard Rectangle", 4, 5, 18, 20),
                ShapeTestCase.rectangleSuccess("Should create a Rectangle with Decimal Dimensions", 4.2, 5, 18.4, 21),
                ShapeTestCase.failure("Should return an error on Negative Length", -1, 5, ShapeErrors.NEGATIVE_VALUE_ERROR),
                ShapeTestCase.failure("Should return an error on Negative Breadth", 5, -10, ShapeErrors.NEGATIVE_VALUE_ERROR),
                ShapeTestCase.failure("Should return an error on Zero Breadth", 5, 0, ShapeErrors.ZERO_VALUE_ERROR),
                ShapeTestCase.failure("Should return an error on Zero Length", 0, 5, ShapeErrors.ZERO_VALUE_ERROR)
        );
    }

    @ParameterizedTest
    @MethodSource("rectangleTableProvider")
    void Test_RectangleTable(ShapeTestCase tt) {
        if (tt.expectedErrorMessage != null) {
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
                new Rectangle(tt.dimensionOne, tt.dimensionTwo);
            });
            assertEquals(tt.expectedErrorMessage, exception.getMessage(),
                    "Error message mismatch for: " + tt.testCaseName);
        } else {
            Rectangle rect = new Rectangle(tt.dimensionOne, tt.dimensionTwo);
            assertEquals(tt.expectedArea, rect.calculateArea(),
                    "Area failed for: " + tt.testCaseName);
            assertEquals(tt.expectedPerimeter, rect.calculatePerimeter(),
                    "Perimeter failed for: " + tt.testCaseName);
        }
    }

    static Stream<ShapeTestCase> squareTableProvider() {
        return Stream.of(
                ShapeTestCase.squareSuccess("Should create a Standard Square", 4, 16, 16),
                ShapeTestCase.squareSuccess("Should create a Square with Decimal Sides", 2.5, 10.0, 6.25),
                ShapeTestCase.failure("Should return an error on Negative Side", -5, 0, ShapeErrors.NEGATIVE_VALUE_ERROR),
                ShapeTestCase.failure("Should return an error on Zero Side", 0, 0, ShapeErrors.ZERO_VALUE_ERROR)
        );
    }

    @ParameterizedTest
    @MethodSource("squareTableProvider")
    void Test_SqaureTable(ShapeTestCase tt) {
        if (tt.expectedErrorMessage != null) {
            IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
                new Square(tt.dimensionOne);
            });
            assertEquals(tt.expectedErrorMessage, exception.getMessage(),
                    "Error message mismatch for: " + tt.testCaseName);
        } else {
            Square square = new Square(tt.dimensionOne);
            assertEquals(tt.expectedArea, square.calculateArea(),
                    "Area failed for: " + tt.testCaseName);
            assertEquals(tt.expectedPerimeter, square.calculatePerimeter(),
                    "Perimeter failed for: " + tt.testCaseName);
        }
    }
}