package org.example;

abstract class Shape {
    public abstract double calculateArea();
    public abstract double calculatePerimeter();
}

class Rectangle extends Shape {
    private final double rectangleLength;
    private final double rectangleBreadth;

    public Rectangle(double rectangleLength, double rectangleBreadth) {
        if (rectangleLength < 0 || rectangleBreadth < 0) {
            throw new IllegalArgumentException(ShapeErrors.NEGATIVE_VALUE_ERROR);
        }
        if (rectangleLength == 0 || rectangleBreadth == 0) {
            throw new IllegalArgumentException(ShapeErrors.ZERO_VALUE_ERROR);
        }
        this.rectangleLength = rectangleLength;
        this.rectangleBreadth = rectangleBreadth;
    }

    @Override
    public double calculateArea() {
        return rectangleLength * rectangleBreadth;
    }

    @Override
    public double calculatePerimeter() {
        return 2 * (rectangleLength + rectangleBreadth);
    }
}

class Square extends Shape {
    private final double squareLength;

    public Square(double squareLength) {
        if (squareLength < 0) {
            throw new IllegalArgumentException(ShapeErrors.NEGATIVE_VALUE_ERROR);
        }
        if (squareLength == 0) {
            throw new IllegalArgumentException(ShapeErrors.ZERO_VALUE_ERROR);
        }
        this.squareLength = squareLength;
    }

    @Override
    public double calculateArea() {
        return squareLength * squareLength;
    }

    @Override
    public double calculatePerimeter() {
        return 4 * squareLength;
    }
}