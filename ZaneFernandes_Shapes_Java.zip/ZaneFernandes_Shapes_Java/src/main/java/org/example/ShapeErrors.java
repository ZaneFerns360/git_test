package org.example;

public class ShapeErrors {
    public static final String NEGATIVE_VALUE_ERROR = "Values provided cannot be negative";
    public static final String ZERO_VALUE_ERROR = "Values provided cannot be zero";
}