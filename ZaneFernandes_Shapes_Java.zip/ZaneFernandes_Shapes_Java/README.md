# Shapes TDD

A Java 25 project using Table-Driven Tests with JUnit 5.

## Prerequisites

* **Java 25 (JDK 25)**
* **Gradle** (Kotlin DSL)

### Mac / Linux
```bash
./gradlew test --tests "org.example.ShapesTest" -i
```
### Windows
```powershell
.\gradlew.bat test -i
```

## How to Build

To compile the project and check for errors without running tests:

```bash
.\gradlew.bat test --tests "org.example.ShapesTest" -i
```

## Project Structure

```text
src
├── main
│   └── java/org/example
│       ├── Shapes.java       # Implementation
│       └── ShapeErrors.java  # Error constants
└── test
    └── java/org/example
        └── ShapesTest.java   # Table Unit Tests
```