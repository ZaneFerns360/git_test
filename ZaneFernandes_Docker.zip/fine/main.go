package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
)

func main() {
	// Initialize the Gin router with default middleware (logger and recovery)
	router := gin.Default()

	router.GET("/hello", helloHandler)

	router.Run(":8080")
}

func helloHandler(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"message": "Hello, Gin!",
	})
}
